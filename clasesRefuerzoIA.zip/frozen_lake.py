# -*- coding: utf-8 -*-
"""
Created on Sat Jun 10 14:04:54 2023

@author: julio
"""

import gymnasium as gym
from gymnasium.envs.toy_text.frozen_lake import generate_random_map
from gymnasium.wrappers import RecordEpisodeStatistics

import algoritmos
import aprendizaje_por_refuerzo

número_episodios = 1000


env = gym.make("FrozenLake-v1", desc=generate_random_map(size=5), render_mode="rgb_array", is_slippery=False)

wrapped = RecordEpisodeStatistics(env, número_episodios)

epsilon = 0.3
p_voraz = aprendizaje_por_refuerzo.PolíticaVoraz()
p_epsilon_voraz = aprendizaje_por_refuerzo.PolíticaEpsilonVoraz(epsilon)
politicas = [p_voraz, p_epsilon_voraz]

if __name__ == '__main__':
    for i in range(2):
        print("Qlearning con política ",politicas[i],":")
        algoritmos.QLearning(wrapped, politicas[i], número_episodios)
   
    print("Montecarlo con política voraz:")
    algoritmos.Montecarlo(wrapped, número_episodios)
   
    for i in range(2):
        print("SARSA con política ",politicas[i],":")
        algoritmos.SARSA(wrapped, politicas[i], número_episodios)
   