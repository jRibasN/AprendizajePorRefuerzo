# -*- coding: utf-8 -*-
"""
Created on Mon Jun 12 16:17:42 2023

@author: julio
"""

import numpy as np
import random

import gymnasium as gym
from gymnasium import spaces
from gymnasium.envs.registration import register

register(
    id='golf-v0',
    entry_point='golf_env:GolfEnv',
)


class GolfEnv(gym.Env):
    def __init__(self):
        # Definir el tamaño del campo de juego
        self.width = 10
        self.height = 10
        
        # Definir las posiciones de salida y del hoyo
        self.start_positions = [(0, 0), (0, self.height-1), (self.width-1, 0), (self.width-1, self.height-1)]
        self.goal_position = (self.width//2, self.height//2)
        
        # Definir las acciones disponibles
        self.actions = [(dx, dy) for dx in range(-1, 2) for dy in range(-1, 2)]
        self.num_clubs = 2
        self.action_space = spaces.Tuple((spaces.Discrete(self.num_clubs), spaces.Discrete(9)))
        
        # Definir el espacio de observación
        self.observation_space = spaces.Tuple((spaces.Discrete(self.width), spaces.Discrete(self.height)))
        
        # Variables de estado
        self.current_position = None
        self.current_strokes = None
        self.current_club = None
        self.out_of_bounds = False
        
        self.reset()
    
    def reset(self, seed=None, options=None):
        if seed is not None:
            np.random.seed(seed)
    
        if options is not None:
            # Aquí puedes procesar las opciones adicionales que se pasen al método reset
            # y realizar cualquier configuración adicional del entorno según sea necesario.
            pass
        # Reiniciar el estado del entorno
        self.current_position = random.choice(self.start_positions)
        self.current_strokes = 0
        self.current_club = 0
        self.out_of_bounds = False
        return self.current_position, {}  # Devolver una tupla (current_position, None)

    
    def step(self, action):
        club, force = action
        
        if club == 0:
            min_force = 5
            max_force = 8
            min_i = -3
            max_i = 3
        else:
            min_force = 1
            max_force = 3
            min_i = -1
            max_i = 1
        
        force = np.clip(force, min_force, max_force)
        i = np.random.randint(min_i, max_i+1)
        dx, dy = self.actions[club]
        
        new_position = (self.current_position[0] + (force + i) * dx, self.current_position[1] + (force + i) * dy)
        
        # Comprobar si la nueva posición está fuera del campo de juego
        if new_position[0] < 0 or new_position[0] >= self.width or new_position[1] < 0 or new_position[1] >= self.height:
            self.out_of_bounds = True
        else:
            self.out_of_bounds = False
            self.current_position = new_position
            self.current_strokes += 1
        
        # Comprobar si se ha llegado al hoyo
        done = self.current_position == self.goal_position or self.out_of_bounds
        
        # Calcular la recompensa
        if self.out_of_bounds:
            reward = -10
        elif done:
            if self.current_position == self.goal_position:
                reward = -self.current_strokes
            else:
                reward = -100
        else:
            reward = -1
        
        return (self.current_position,), reward, done, {}
