# -*- coding: utf-8 -*-
"""
Created on Sun Jun 11 18:59:41 2023

@author: julio
"""
import numpy as np
from matplotlib import pyplot as plt

def plot_recompensa_acumulada(recompensas):
    plt.plot(np.cumsum(recompensas))
    media_valores = np.mean(recompensas)
    titulo = f'Recompensa acumulada (Media por episodio: {media_valores:.2f})'
    plt.title(titulo)
    plt.xlabel("Episodios")
    plt.ylabel("Recompensas")
    plt.show()
    
def plot_longitud_episodios(pasos):
    plt.plot(pasos)
    media_valores = np.mean(pasos)
    titulo = f'Longitud de los episodios (Media: {media_valores:.2f})'
    plt.title(titulo)
    plt.xlabel("Episodios")
    plt.ylabel("Pasos")
    plt.show()
    