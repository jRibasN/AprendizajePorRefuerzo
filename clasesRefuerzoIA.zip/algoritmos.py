# -*- coding: utf-8 -*-
"""
Created on Sun Jun 11 20:31:50 2023

@author: julio
"""
import time

import aprendizaje_por_refuerzo
import gráficos

def QLearning(env = None ,politica = None, número_episodios = None):
   factor_de_descuento = 0.95
   tasa_de_aprendizaje = 0.1
   env.reset()
   algoritmo = aprendizaje_por_refuerzo.Q_Learning(env, factor_de_descuento, tasa_de_aprendizaje,
                                                   politica)

   inicio = time.time()
   algoritmo.entrena(número_episodios)
   fin = time.time()

   print("Tiempo de ejecución: ",fin - inicio)


   recompensas = tuple(env.return_queue)
   episodios = tuple(env.length_queue)
   tabla_recompensas = []
   tabla_episodios = []
   longitud_acumulada = 0

   for e in range(len(recompensas)):
      tabla_recompensas.append(float(recompensas[e][0]))
   for e in range(len(episodios)):
      tabla_episodios.append(int(episodios[e][0]))
      longitud_acumulada += float(episodios[e][0])

   gráficos.plot_recompensa_acumulada(tabla_recompensas)
   gráficos.plot_longitud_episodios(tabla_episodios)



def Montecarlo(env = None, número_episodios = None):
   factor_de_descuento = 0.95
   env.reset()
   algoritmo = aprendizaje_por_refuerzo.Montecarlo_IE(env, factor_de_descuento)

   inicio = time.time()
   algoritmo.entrena(número_episodios)
   fin = time.time()

   print("Tiempo de ejecución: ",fin - inicio)

   recompensas = tuple(env.return_queue)
   episodios = tuple(env.length_queue)
   tabla_recompensas = []
   tabla_episodios = []
   longitud_acumulada = 0

   for e in range(len(recompensas)):
      tabla_recompensas.append(float(recompensas[e][0]))
   for e in range(len(episodios)):
      tabla_episodios.append(int(episodios[e][0]))
      longitud_acumulada += float(episodios[e][0])

   gráficos.plot_recompensa_acumulada(tabla_recompensas)
   gráficos.plot_longitud_episodios(tabla_episodios)


def SARSA(env = None ,politica = None, número_episodios = None):
   factor_de_descuento = 0.95
   tasa_de_aprendizaje = 0.1
   env.reset()
   algoritmo = aprendizaje_por_refuerzo.SARSA(env, factor_de_descuento, tasa_de_aprendizaje,
                                                   politica)
   inicio = time.time()
   algoritmo.entrena(número_episodios)
   fin = time.time()

   print("Tiempo de ejecución: ",fin - inicio)


   recompensas = tuple(env.return_queue)
   episodios = tuple(env.length_queue)
   tabla_recompensas = []
   tabla_episodios = []
   longitud_acumulada = 0

   for e in range(len(recompensas)):
      tabla_recompensas.append(float(recompensas[e][0]))
   for e in range(len(episodios)):
      tabla_episodios.append(int(episodios[e][0]))
      longitud_acumulada += float(episodios[e][0])

   gráficos.plot_recompensa_acumulada(tabla_recompensas)
   gráficos.plot_longitud_episodios(tabla_episodios)