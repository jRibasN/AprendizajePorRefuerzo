# -*- coding: utf-8 -*-
"""
Created on Sun Jun 11 20:44:45 2023

@author: julio
"""

import gymnasium as gym
from gymnasium.wrappers import RecordEpisodeStatistics

import algoritmos
import aprendizaje_por_refuerzo

número_episodios = 10000

env = gym.make("Taxi-v3", render_mode="rgb_array")
wrapped = RecordEpisodeStatistics(env, número_episodios)

epsilon = 0.1
p_voraz = aprendizaje_por_refuerzo.PolíticaVoraz()
p_epsilon_voraz = aprendizaje_por_refuerzo.PolíticaEpsilonVoraz(epsilon)
politicas = [p_voraz, p_epsilon_voraz]

if __name__ == '__main__':
    for i in range(2):
        print("Qlearning con política ",politicas[i],":")
        algoritmos.QLearning(wrapped, politicas[i], número_episodios)
   
    print("Montecarlo con política voraz:")
    algoritmos.Montecarlo(wrapped, número_episodios/10)
   
    for i in range(2):
        print("SARSA con política ",politicas[i],":")
        algoritmos.SARSA(wrapped, politicas[i], número_episodios)